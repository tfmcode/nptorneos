/* import API from "./httpClient";
import { Proveedor, ProveedorInput } from "../types/proveedores";

export const getProveedores = async (
  page = 1,
  limit = 10,
  searchTerm = ""
): Promise<{
  proveedores: Proveedor[];
  total: number;
  page: number;
  limit: number;
}> => {
  const res = await API.get("/api/proveedores", {
    params: { page, limit, searchTerm },
  });
  return res.data;
};

export const getProveedorById = async (id: number): Promise<Proveedor> => {
  const res = await API.get(`/api/proveedores/${id}`);
  return res.data;
};

export const createProveedor = async (
  proveedorData: ProveedorInput
): Promise<Proveedor> => {
  const res = await API.post("/api/proveedores", proveedorData);
  return res.data.registro;
};

export const updateProveedor = async (
  id: number,
  proveedorData: ProveedorInput
): Promise<Proveedor> => {
  const res = await API.put(`/api/proveedores/${id}`, proveedorData);
  return res.data.registro;
};

export const deleteProveedor = async (id: number): Promise<void> => {
  await API.delete(`/api/proveedores/${id}`);
};
 */

import { Proveedor } from "../types/proveedores";

// Mock de datos de prueba
const mockProveedores: Proveedor[] = [
  { id: 1, codtipo: 1, nombre: "Árbitro 1" },
  { id: 2, codtipo: 2, nombre: "Profesor 1" },
  { id: 3, codtipo: 3, nombre: "Médico 1" },
  { id: 4, codtipo: 4, nombre: "Proveedor General 1" },
];

// Simular latencia de red
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const getProveedores = async (
  page: number,
  limit: number,
  searchTerm: string
) => {
  await delay(300); // simula carga

  // filtrar mock según búsqueda
  const filtered = mockProveedores.filter((prov) =>
    prov.id.toString().includes(searchTerm.toLowerCase())
  );

  return {
    proveedores: filtered,
    total: filtered.length,
    page,
    limit,
  };
};

export const createProveedor = async (proveedorData: Omit<Proveedor, "id">) => {
  await delay(300);
  const newProveedor: Proveedor = {
    ...proveedorData,
    id: Math.floor(Math.random() * 1000) + 5,
    nombre: "Nuevo Proveedor", // nombre simulado
  };
  mockProveedores.push(newProveedor);
  return newProveedor;
};

export const updateProveedor = async (
  id: number,
  data: Omit<Proveedor, "id">
) => {
  await delay(300);
  const index = mockProveedores.findIndex((p) => p.id === id);
  if (index !== -1) {
    mockProveedores[index] = { id, ...data };
    return mockProveedores[index];
  }
  throw new Error("Proveedor no encontrado");
};

export const deleteProveedor = async (id: number) => {
  await delay(300);
  const index = mockProveedores.findIndex((p) => p.id === id);
  if (index !== -1) {
    mockProveedores.splice(index, 1);
  } else {
    throw new Error("Proveedor no encontrado");
  }
};
