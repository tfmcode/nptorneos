import { Codificador } from "../../../types/codificador";

export const codificadorColumns = [
  {
    header: "Descripción",
    accessor: "descripcion" as keyof Codificador,
  },
];
