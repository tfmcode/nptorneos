import { Proveedor } from "../../../types/proveedores";

export const proveedoresColumns = [
  {
    header: "Tipo",
    accessor: "codtipo" as keyof Proveedor,
    render: (proveedor: Proveedor) => {
      switch (proveedor.codtipo) {
        case 1:
          return "ÁRBITRO";
        case 2:
          return "PROFESOR";
        case 3:
          return "SERV. MÉDICO";
        case 4:
          return "OTROS";
        default:
          return "—";
      }
    },
  },
  {
    header: "Nombre",
    accessor: "nombre" as keyof Proveedor,
  },
];
