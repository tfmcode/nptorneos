import { Sede } from "../../../types/sede";

export const sedeColumns = [
  {
    header: "Nombre",
    accessor: "nombre" as keyof Sede,
  },
];
