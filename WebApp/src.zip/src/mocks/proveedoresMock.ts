// src/mocks/proveedoresMock.ts

import { Proveedor } from "../types/proveedores";

export const proveedoresMock: Proveedor[] = [
  {
    id: 1,
    codtipo: 1,
    nombre: "Juan Pérez",
  },
  {
    id: 2,
    codtipo: 2,
    nombre: "María López",
  },
  {
    id: 3,
    codtipo: 3,
    nombre: "Clínica San José",
  },
  {
    id: 4,
    codtipo: 4,
    nombre: "Proveedor Genérico",
  },
];
