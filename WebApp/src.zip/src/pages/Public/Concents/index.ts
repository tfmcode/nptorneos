export { default as Concents } from './Concents';
