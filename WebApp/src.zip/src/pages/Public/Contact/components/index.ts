export { default as ContactInfo } from './ContactInfo';
export { default as RegistrationForm } from './RegistrationForm';
