export { default as HeroCarousel } from './HeroCarousel';
export { default as LogosCloud } from './LogosCloud';
export { default as NewSections } from './NewSections';
export { default as OverlayImage } from './OverlayImage';
export { default as SocialMedia } from './SocialMedia';
