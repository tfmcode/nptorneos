import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../../store";
import { Proveedor, ProveedorInput } from "../../types/proveedores";
import DataTable from "../../components/tables/DataTable";
import DynamicForm from "../../components/forms/DynamicForm";
import { PlusCircleIcon } from "@heroicons/react/20/solid";
import {
  fetchProveedores,
  createProveedorThunk,
  updateProveedorThunk,
  deleteProveedorThunk,
} from "../../store/slices/proveedoresSlice";
import {
  Modal,
  PageHeader,
  StatusMessage,
  SearchField,
} from "../../components/common";
import { proveedoresColumns } from "../../components/tables/columns/proveedoresColumns";
import { useCrudForm } from "../../hooks/useCrudForm";

const codtipoOptions = [
  { label: "ÁRBITRO", value: 1 },
  { label: "PROFESOR", value: 2 },
  { label: "SERV. MÉDICO", value: 3 },
  { label: "OTROS", value: 4 },
];

const Proveedores: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { proveedores, loading, error, page, limit } = useSelector(
    (state: RootState) => state.proveedores
  );

  const {
    formData,
    isModalOpen,
    handleInputChange,
    handleOpenModal,
    handleCloseModal,
  } = useCrudForm<ProveedorInput>({
    id: undefined,
    codtipo: 4,
    nombre: "",
  });

  const [pendingSearchTerm, setPendingSearchTerm] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    dispatch(fetchProveedores({ page, limit, searchTerm }));
  }, [dispatch, page, limit, searchTerm]);

  const handleSearch = () => {
    setSearchTerm(pendingSearchTerm);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nombre || formData.nombre.trim() === "") {
      alert("El nombre es obligatorio.");
      return;
    }

    try {
      if (formData.id) {
        // Update
        await dispatch(
          updateProveedorThunk({
            id: formData.id,
            data: formData,
          })
        ).unwrap();
      } else {
        // Create
        await dispatch(createProveedorThunk(formData)).unwrap();
      }
      handleCloseModal();
    } catch (err) {
      console.error("❌ Error al guardar proveedor:", err);
      alert("Error al guardar proveedor.");
    }
  };

  const handleDelete = async (proveedor: Proveedor) => {
    if (!window.confirm("¿Estás seguro de eliminar este proveedor?")) return;
    try {
      await dispatch(deleteProveedorThunk(proveedor.id!)).unwrap();
    } catch (err) {
      console.error("❌ Error al eliminar proveedor:", err);
    }
  };

  const filteredProveedores = proveedores.filter((prov) =>
    prov.nombre?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex justify-center items-center">
      <div className="bg-white shadow-lg rounded-lg p-6 w-full max-w-4xl">
        <PageHeader
          title="Proveedores"
          actions={[
            {
              label: "Nuevo",
              onClick: () => handleOpenModal(),
              icon: <PlusCircleIcon className="h-5 w-5" />,
            },
          ]}
        />

        <div className="mb-4">
          <SearchField
            placeholder="Buscar por nombre"
            value={pendingSearchTerm}
            onChange={(e) => setPendingSearchTerm(e.target.value)}
            onSearch={handleSearch}
          />
        </div>

        <StatusMessage loading={loading} error={error} />

        <DataTable<Proveedor>
          columns={proveedoresColumns}
          data={filteredProveedores}
          onEdit={(row) => handleOpenModal(row as Proveedor)}
          onDelete={(row) => handleDelete(row as Proveedor)}
        />

        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={formData.id ? "Editar Proveedor" : "Nuevo Proveedor"}
        >
          <DynamicForm
            fields={[
              {
                name: "codtipo",
                type: "select",
                label: "Tipo de Proveedor",
                options: codtipoOptions,
                value: formData.codtipo ?? 4,
              },
              {
                name: "nombre",
                type: "text",
                label: "Nombre",
                placeholder: "Ingrese el nombre del proveedor",
                value: formData.nombre ?? "",
              },
            ]}
            onChange={handleInputChange}
            onSubmit={handleSubmit}
            submitLabel="Guardar"
          />
        </Modal>
      </div>
    </div>
  );
};

export default Proveedores;
