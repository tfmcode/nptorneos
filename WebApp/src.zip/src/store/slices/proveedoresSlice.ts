import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import {
  getProveedores,
  createProveedor,
  updateProveedor,
  deleteProveedor,
} from "../../api/proveedoresService";
import { Proveedor, ProveedorInput } from "../../types/proveedores";

interface ProveedoresState {
  proveedores: Proveedor[];
  total: number;
  page: number;
  limit: number;
  loading: boolean;
  error: string | null;
}

const initialState: ProveedoresState = {
  proveedores: [],
  total: 0,
  page: 1,
  limit: 10,
  loading: false,
  error: null,
};

export const fetchProveedores = createAsyncThunk(
  "proveedores/fetchProveedores",
  async (
    {
      page,
      limit,
      searchTerm,
    }: { page: number; limit: number; searchTerm: string },
    { rejectWithValue }
  ) => {
    try {
      return await getProveedores(page, limit, searchTerm);
    } catch (error: unknown) {
      return rejectWithValue(
        (error as Error).message || "Error al obtener proveedores."
      );
    }
  }
);

export const createProveedorThunk = createAsyncThunk(
  "proveedores/createProveedor",
  async (proveedorData: ProveedorInput, { rejectWithValue }) => {
    try {
      return await createProveedor(proveedorData);
    } catch (error: unknown) {
      return rejectWithValue(
        (error as Error).message || "Error al crear proveedor."
      );
    }
  }
);

export const updateProveedorThunk = createAsyncThunk(
  "proveedores/updateProveedor",
  async (
    { id, data }: { id: number; data: ProveedorInput },
    { rejectWithValue }
  ) => {
    try {
      return await updateProveedor(id, data);
    } catch (error: unknown) {
      return rejectWithValue(
        (error as Error).message || "Error al actualizar proveedor."
      );
    }
  }
);

export const deleteProveedorThunk = createAsyncThunk(
  "proveedores/deleteProveedor",
  async (id: number, { rejectWithValue }) => {
    try {
      await deleteProveedor(id);
      return id;
    } catch (error: unknown) {
      return rejectWithValue(
        (error as Error).message || "Error al eliminar proveedor."
      );
    }
  }
);

const proveedoresSlice = createSlice({
  name: "proveedores",
  initialState,
  reducers: {
    /**
     * ✅ Para uso con mocks en desarrollo
     * dispatch(setProveedoresMock(proveedoresMock));
     */
    setProveedoresMock: (state, action: PayloadAction<Proveedor[]>) => {
      state.proveedores = action.payload;
      state.total = action.payload.length;
      state.page = 1;
      state.limit = 10;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProveedores.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchProveedores.fulfilled, (state, action) => {
        state.loading = false;
        state.proveedores = action.payload.proveedores;
        state.total = action.payload.total;
        state.page = action.payload.page;
        state.limit = action.payload.limit;
      })
      .addCase(fetchProveedores.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(createProveedorThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createProveedorThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.proveedores.unshift(action.payload);
      })
      .addCase(createProveedorThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(updateProveedorThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateProveedorThunk.fulfilled, (state, action) => {
        state.loading = false;
        const updated = action.payload;
        const idx = state.proveedores.findIndex((p) => p.id === updated.id);
        if (idx !== -1) {
          state.proveedores[idx] = updated;
        }
      })
      .addCase(updateProveedorThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(deleteProveedorThunk.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteProveedorThunk.fulfilled, (state, action) => {
        state.loading = false;
        state.proveedores = state.proveedores.filter(
          (p) => p.id !== action.payload
        );
      })
      .addCase(deleteProveedorThunk.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setProveedoresMock } = proveedoresSlice.actions;
export default proveedoresSlice.reducer;
