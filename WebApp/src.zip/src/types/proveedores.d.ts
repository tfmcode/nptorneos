export interface Proveedor {
  id: number;
  codtipo?: number;
  nombre?: string;
  domicilio?: string;
  cpostal?: string;
  localidad?: string;
  provincia?: string;
  telefono?: string;
  email?: string;
  celular?: string;
  valor_fijo?: number;
  fhcarga?: string;
  fhbaja?: string | null;
  valor_hora?: number;
  contrasenia?: string;
  sedes?: string;
  documento?: string;
  fhnac?: string;
  estcivil?: string;
  hijos?: string;
  estudios?: string;
  facebook?: string;
  nombrefiscal?: string;
  codcateg?: number;
  cuit?: string;
  pais?: string;
  fax?: string;
  contacto?: string;
  producto?: string;
  codtipogasto?: number;
  sumarhs?: number;
  [key: string]: unknown;
}

export interface ProveedorInput {
  id?: number;
  codtipo?: number;
  nombre?: string;
  domicilio?: string;
  cpostal?: string;
  localidad?: string;
  provincia?: string;
  telefono?: string;
  email?: string;
  celular?: string;
  valor_fijo?: number;
  valor_hora?: number;
  contrasenia?: string;
  sedes?: string;
  documento?: string;
  fhnac?: string; // YYYY-MM-DD
  estcivil?: string;
  hijos?: string;
  estudios?: string;
  facebook?: string;
  nombrefiscal?: string;
  codcateg?: number;
  cuit?: string;
  pais?: string;
  fax?: string;
  contacto?: string;
  producto?: string;
  codtipogasto?: number;
  sumarhs?: number;
  [key: string]: unknown;
}
